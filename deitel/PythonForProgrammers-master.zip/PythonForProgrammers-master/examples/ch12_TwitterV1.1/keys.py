consumer_key = 'YourConsumerKey'
consumer_secret = 'YourConsumerSecret'
access_token = 'YourAccessToken'
access_token_secret = 'YourAccessTokenSecret'

mapquest_key = 'YourAPIKey'