Unlike the prior chapters, any snippet files and notebook files 
are located in the example folders mentioned in each section.

Some examples were implemented only in notebooks because they 
execute in cloud-based cluster environments.
